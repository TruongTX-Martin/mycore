package com.simicart.plugins.locator;

public class SaveChooseOfUser {

	public static int choose = 0;
}
