package com.simicart.plugins.download.delegate;

import com.simicart.core.base.delegate.SimiDelegate;

public interface DownloadDelegate extends SimiDelegate{
	public void getMessage(String message);
}	
