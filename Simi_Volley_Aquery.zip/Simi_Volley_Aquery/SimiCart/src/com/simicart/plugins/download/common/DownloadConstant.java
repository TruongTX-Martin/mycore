package com.simicart.plugins.download.common;


public class DownloadConstant {
	public static String ORDER_ID = "order_id";
	public static String ORDER_DATE = "order_date";
	public static String ORDER_NAME = "order_name";
	public static String ORDER_LINK = "order_link";
	public static String ORDER_STATUS = "order_status";
	public static String ORDER_REMAIN = "order_remain";
	public static String FILE_NAME = "order_file";
	public static String COOKIE = "";
	public static final String STATUS = "Status";
	public static final String TASKS = "Downloading";
	public static final String PREF = "SimicartDownloadService";
	public static final String DOWNLOAD_ACTION = "Simi";
	public static final String DOWNLOADING_ACTION = "SimiDownloading";
	public static int currentTab = 0;
}
