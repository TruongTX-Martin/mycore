package com.simicart.plugins.youtube.common;

public class DeveloperKey {
	public static final String DEVELOPER_KEY = "AIzaSyD8GPps7zSu8OMY6KiiJAhHhFVQnFTbPJs";
}
