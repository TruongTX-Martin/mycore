package com.simicart.plugins.barcode;

public class ConstantBarcode {

	// public static final String SCANNER =
	// "com.google.zxing.client.android.SCAN";
	// public static final String SCAN_MODE_BARCODE =
	// "UPC_A,UPC_E,EAN_8,EAN_13,CODE_39,CODE_93,CODE_128";
	// public static final String SCAN_MODE = "QR_CODE_MODE";
	// public static final String SCAN_MODE_BARCODE = "BAR_CODE_MODE";

	public static final String SCAN_NOW = "Scan QR Barcode";
	public static final String QR_BAR_CODE = "Scan Now";
}
