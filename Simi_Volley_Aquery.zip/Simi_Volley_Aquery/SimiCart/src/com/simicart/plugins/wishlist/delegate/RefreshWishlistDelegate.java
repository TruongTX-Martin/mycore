package com.simicart.plugins.wishlist.delegate;


public interface RefreshWishlistDelegate {

	public void refreshWishlist (int position);
}
