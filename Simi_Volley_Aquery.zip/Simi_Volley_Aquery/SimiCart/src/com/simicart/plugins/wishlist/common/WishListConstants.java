package com.simicart.plugins.wishlist.common;

public class WishListConstants {
	public static String MY_WISHLIST = "My Wishlist";

	public static String SHARING_MESSAGE = "sharing_message";
	public static String WISHLIST_INFO = "wishlist_info";
	public static String WISHLIST_ITEMS_QTY = "wishlist_items_qty";
	public static String WISHLIST_ITEM_ID = "wishlist_item_id";
	public static String PRODUCT_SHARING_URL = "product_sharing_url";
	public static String PRODUCT_SHARING_MESSAGE = "product_sharing_message";
	public static String SELECTED_ALL_REQUIRED_OPTIONS = "selected_all_required_options";
}
