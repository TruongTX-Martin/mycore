package com.simicart.core.base.delegate;

public interface ModelDelegate {
	public abstract void callBack(String message, boolean isSuccess);
}
