package com.simicart.core.home.delegate;

import com.simicart.core.base.delegate.SimiDelegate;

public interface CategoryHomeDelegate extends SimiDelegate{
	

}
