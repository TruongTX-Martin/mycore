package com.simicart.core.banner.delegate;

import com.simicart.core.base.delegate.SimiDelegate;

public interface BannerDelegate extends SimiDelegate{
	

}
