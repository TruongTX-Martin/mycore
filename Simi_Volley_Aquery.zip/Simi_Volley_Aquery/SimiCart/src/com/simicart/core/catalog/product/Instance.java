package com.simicart.core.catalog.product;

import java.util.Calendar;

public class Instance {
	
	public static int POSITION_START;
	public static int POSITION_END;
	public static int FLAG_CLICK ;
	public static Calendar currenDate = Calendar.getInstance();

}
