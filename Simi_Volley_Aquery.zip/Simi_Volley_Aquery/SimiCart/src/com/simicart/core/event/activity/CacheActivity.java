package com.simicart.core.event.activity;

import android.app.Activity;

public class CacheActivity {
	private Activity activity;

	public void setActivity(Activity activity) {
		this.activity = activity;
	}

	public Activity getActivity() {
		return activity;
	}
}
