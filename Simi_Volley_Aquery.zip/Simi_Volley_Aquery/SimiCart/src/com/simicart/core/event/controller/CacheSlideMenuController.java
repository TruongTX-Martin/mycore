package com.simicart.core.event.controller;

import com.simicart.core.slidemenu.controller.PhoneSlideMenuController;

public class CacheSlideMenuController {

	protected PhoneSlideMenuController mController;

	public PhoneSlideMenuController getController() {
		return mController;
	}

	public void setController(PhoneSlideMenuController mController) {
		this.mController = mController;
	}

}
