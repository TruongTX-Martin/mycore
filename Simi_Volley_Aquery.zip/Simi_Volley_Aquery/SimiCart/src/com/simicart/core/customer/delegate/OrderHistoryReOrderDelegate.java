package com.simicart.core.customer.delegate;

import com.simicart.core.base.delegate.SimiDelegate;
import com.simicart.core.material.ButtonRectangle;

public interface OrderHistoryReOrderDelegate extends SimiDelegate{
	public ButtonRectangle reOrder();
}
