package com.simicart.core.customer.delegate;

import com.simicart.core.base.delegate.SimiDelegate;

public interface OrderHistoryDelegate extends SimiDelegate {
	public void addFooterView();

	public void removeFooterView();
}
