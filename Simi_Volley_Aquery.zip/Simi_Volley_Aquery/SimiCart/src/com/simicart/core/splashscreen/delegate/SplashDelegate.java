package com.simicart.core.splashscreen.delegate;

public interface SplashDelegate {
	
	public void creatMain();

}
