package com.simicart.core.cms.block;

import android.content.Context;
import android.view.View;

import com.simicart.core.base.block.SimiBlock;

public class CMSBlock extends SimiBlock {

	public CMSBlock(View view, Context context) {
		super(view, context);
		// TODO Auto-generated constructor stub
	}

}
