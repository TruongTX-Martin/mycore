package com.simicart.core.checkout.delegate;

import com.simicart.core.base.delegate.SimiDelegate;

public interface CreditCardDelegate extends SimiDelegate {

	public void onCLickSave();

}
